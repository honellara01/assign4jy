export class Quotes {
  constructor(
    public id: string,
    public person: string,
    public text: string,
  ){}
  }