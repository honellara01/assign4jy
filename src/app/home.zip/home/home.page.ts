import { Component, OnInit } from '@angular/core';
import { Quotes } from './quotes.model';
import { QuoteService } from './quote.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
quotesCollection: Quotes[];

  constructor(private quoteService: QuoteService) {}
  ngOnInit(){
    this.quotesCollection = this.quoteService.quotes;
  }
  ionViewWillEnter(){
    this.quotesCollection =this.quoteService.quotes;
  }

}
